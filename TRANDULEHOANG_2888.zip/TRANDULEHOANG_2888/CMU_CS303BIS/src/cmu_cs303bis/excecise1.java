package cmu_cs303bis;

public class excecise1 {

    public static void main(String[] args) {
        int a = 3;
        int b = 6;
        System.out.println("Tong: " + (a + b));
        System.out.println("Hieu: " + (b - a));
        System.out.println("Thuong: " + (b / a));
        System.out.println("Tich: " + (a * b));

    }
}
